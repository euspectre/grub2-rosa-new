files=*.po
for file in $files
do
    msgcat ../po/$file $file -o ../po/$file --use-first
    gmo_file=`echo $file | sed "s/.po/.gmo/"`
    msgfmt ../po/$file -o ../po/$gmo_file
done